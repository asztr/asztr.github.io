# lbe2d

Requirements: qmake, libfftw3, Qt

Compilation:
	qmake
	make

Usage:
	./lbe2d
	Left-click: move the fluid.
	Right-click: build a rigid block. 
	Press "d" to change the visualization mode.
