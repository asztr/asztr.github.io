#ifndef VEC3_H
#define VEC3_H

#endif // VEC3_H
