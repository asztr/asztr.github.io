#ifndef RAY_H
#define RAY_H

#endif // RAY_H
