Additional Material: Results
----------------------------

results_real.pdf
	Portrait: real portrait image.
	GT Envmap: Ground truth environment map.
	GT Envmap High: L_high of GT environment map.
	Gauss Fit Envmap High: Gaussian Fit of L_high.
	Gauss Pred Envmap High: Gaussian Fit predicted by Face2Env.
	Pred Envmap (Our): Environment map predicted by Face2Env (pred L_low + pred L_high).
	Pred Envmap (Calian): Environment map predicted by Calian et al.
	GT Rendering: rendering of synthetic face using GT Envmap as source illumination.
	Pred Rendering (Our): rendering of synthetic face using "Pred Envmap (Our)" as source illumination.
	Pred Rendering (Calian): rendering of synthetic face using "Pred Envmap (Calian)" as source illumination.

results_synth.pdf
	Portrait: synthetic portrait image.
	GT Envmap: Ground truth environment map.
	GT Envmap High: L_high of GT environment map.
	Gauss Fit Envmap High: Gaussian Fit of L_high.
	Gauss Pred Envmap High: Gaussian Fit predicted by Face2Env.
	Pred Envmap (Our): Environment map predicted by Face2Env (pred L_low + pred L_high).
	GT Rendering: rendering of synthetic face using GT Envmap as source illumination.
	Pred Rendering (Our): rendering of synthetic face using "Pred Envmap (Our)" as source illumination.

	
Additional Material: Scripts Usage
----------------------------------

Environment Map Encoding: ./encode_envmap.py samples/sample-envmap.exr
	-> sample-envmap-pred.exr: Environment map encoded by autoencoder + Gaussian Fit

	Additional files created:
	-> sample-envmap-low.exr: L_low
	-> sample-envmap-high.exr: L_high
	-> sample-envmap-high-2dgauss.exr: Gaussian Fit of L_high
	-> sample-envmap-high-2dgauss.yaml: Parameters of Gaussian Fit of L_high
	-> sample-envmap-low-pred.exr: L_low predicted by autoencoder
	-> sample-envmap-low-pred.yaml: Parameters of L_low predicted by autoencoder

Environment Map Prediction from Synth Face: ./face2env.py samples/3drfe-face.png
	-> 3drfe-envmap-gpred.exr: Environment map predicted from face (GT is samples/3drfe-envmap.exr)

	Additional files created:
	-> 3drfe-envmap-gpred.yaml: Predicted parameters/encoding (Z_env)
	-> 3drfe-envmap-high-2dgauss-gpred.exr: Predicted L_high.
	-> 3drfe-envmap-high-2dgauss-gpred.yaml: Predicted L_high parameters.
	-> 3drfe-envmap-low-gpred.exr: Predicted L_low
	-> 3drfe-envmap-low-gpred.yaml: Predicted L_low parameters.

Environment Map Prediction from Real Face: ./face2env.py samples/real-face.png
	-> real-envmap-gpred.exr: Environment map predicted from face (GT is samples/real-envmap.exr)

	Additional files created:
	-> real-envmap-gpred.yaml: Predicted parameters/encoding (Z_env)
	-> real-envmap-high-2dgauss-gpred.exr: Predicted L_high.
	-> real-envmap-high-2dgauss-gpred.yaml: Predicted L_high parameters.
	-> real-envmap-low-gpred.exr: Predicted L_low
	-> real-envmap-low-gpred.yaml: Predicted L_low parameters.
