#!/usr/bin/env python

import os
import os.path as op
import numpy as np
import pyexr
import random
import yaml
import scipy.optimize as opt
import argparse

import keras
import keras.backend as K
from keras.models import load_model

parser = argparse.ArgumentParser()
parser.add_argument('exrs', nargs='+')
args = parser.parse_args()

def yaml_read(fname):
    with open(fname, 'r') as stream:
        try:
            return yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            print(exc)

def yaml_write(fname, data, default_style=False):
    with open(fname, 'w') as outfile:
        yaml.dump(data, outfile, default_flow_style=default_style)


def keep_l(x):
	return np.clip(x, 0.0, 1.0)

def keep_h(x):
	return x - keep_l(x)

def gauss2d(xy, amp, x0, y0):
	x, y = xy
	a = 2.75
	inner = a * (x - x0)**2
	inner += a * (y - y0)**2
	return amp * np.exp(-inner)

def fit_image_channel_to_2dgaussian(img_c):
	shape = img_c.shape
	img_c = np.clip(img_c, 0, np.inf)
	X, Y = np.mgrid[0:shape[0]:1, 0:shape[1]:1]
	xy = np.array([X.flatten(), Y.flatten()])
	zobs = img_c.flatten()

	i = zobs.argmax()
	guess = [zobs.max(), xy[0][i], xy[1][i]] #0, 1]
	pred_params, uncert_cov = opt.curve_fit(gauss2d, xy, zobs, p0=guess)

	zpred = gauss2d(xy, *pred_params)
	img_c_pred = zpred.reshape(shape)
	return img_c_pred, pred_params

def fit_rgb_image_to_2dgaussian(img):
	img_pred, pred_params = [], []
	for irgb in range(3):
		img_c = img[:, :, irgb]
		img_c_pred, pred_c_params = fit_image_channel_to_2dgaussian(img_c)
		img_pred += [img_c_pred]
		pred_params += [pred_c_params]
	img_pred = np.moveaxis(img_pred, 0, -1)
	pred_params = np.array(pred_params)
	return img_pred, pred_params

def imgh_to_gaussparams(imgh):
	imgh_pred, pred_params = fit_rgb_image_to_2dgaussian(imgh)
	p = np.array(pred_params).T
	params = [*p[0], p[1].mean(), p[2].mean()]
	params = [float(num) for num in params]
	return imgh_pred, params


envnet_ae = load_model('models/ae.h5', compile=False)
envnet_enc = load_model('models/enc.h5', compile=False)

for exr in args.exrs:
	img = pyexr.read(exr)[:,:,:3]

	# Compute/Write L_high
	img_h = keep_h(img)
	img_h_fname = exr.replace('.exr', '-high.exr')
	pyexr.write(img_h_fname, img_h)

	# Compute/Write L_low
	img_l = keep_l(img)
	img_l_fname = exr.replace('.exr', '-low.exr')
	pyexr.write(img_l_fname, img_l)

	# Predict/Write autoencoded L_low
	img_l_pred = envnet_ae.predict(img_l[None, ...], batch_size=1)[0]
	img_l_pred_fname = exr.replace('.exr', '-low-pred.exr')
	pyexr.write(img_l_pred_fname, img_l_pred)

	# Predict/Write autoencoded L_low parameters (Z_low)
	img_l_pred_params = envnet_enc.predict(img_l[None, ...], batch_size=1)[0]
	img_l_pred_params = [float(num) for num in np.squeeze(img_l_pred_params)]
	img_l_pred_params_fname = exr.replace('.exr', '-low-pred.yaml')
	yaml_write(img_l_pred_params_fname, img_l_pred_params)

	# Compute/Write Gauss Fit of L_high
	img_h_pred, img_h_pred_params = imgh_to_gaussparams(img_h)
	img_h_pred_fname = exr.replace('.exr', '-high-2dgauss.exr')
	img_h_pred_params_fname = exr.replace('.exr', '-high-2dgauss.yaml')
	pyexr.write(img_h_pred_fname, img_h_pred)
	yaml_write(img_h_pred_params_fname, img_h_pred_params)

	# Compute/Write L_pred = L_low_pred + L_high_pred
	img_pred = img_l_pred + img_h_pred
	img_pred_fname = exr.replace('.exr', '-pred.exr')
	pyexr.write(img_pred_fname, img_pred)

