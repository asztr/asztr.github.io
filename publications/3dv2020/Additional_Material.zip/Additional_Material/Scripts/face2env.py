#!/usr/bin/env python
# coding: utf-8

import sys
import os
import os.path as op
import pandas as pd
import numpy as np
from keras.models import load_model
from keras_contrib.layers.normalization.instancenormalization import InstanceNormalization
import tensorflow as tf
import cv2
import yaml
import pyexr
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('face_imgs', nargs='+')
args = parser.parse_args()

class Dataset:
	def __init__(self, imgs, lums, zenvs, name=None, fnames=None):
		self.length = len(imgs)
		self.imgs = imgs
		self.lums = lums
		self.zenvs = zenvs
		self.name = name
		self.fnames = fnames
		self.ixiy = None
	
	def compute_src_tgt_random_indices(self):
		n = self.length
		self.ixiy = list(itertools.product(range(n), range(n)))
		random.shuffle(self.ixiy)
		return self.ixiy

	def get_vars(self):
		vars_dict = {}
		for k,v in vars(self).items():
			if hasattr(v, '__len__') and (not isinstance(v, str)):
				vars_dict[k] = len(v)
			else:
				vars_dict[k] = v
		return vars_dict

def yaml_read(fname):
    with open(fname, 'r') as stream:
        try:
            return yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            print(exc)

def yaml_write(fname, data, default_style=False):
    with open(fname, 'w') as outfile:
        yaml.dump(data, outfile, default_flow_style=default_style)

def read_ldr(fname):
	img_i = cv2.imread(fname)[:, :, :3]
	img_i = cv2.cvtColor(img_i, cv2.COLOR_BGR2RGB)
	return img_i

def write_ldr(fname, img_i):
	if (len(img_i.shape) == 3) and (img_i.shape[2] == 3):
		cv2.imwrite(fname, cv2.cvtColor(img_i, cv2.COLOR_RGB2BGR))
	else:
		cv2.imwrite(fname, img_i)

def img2lab(img_i):
	return cv2.cvtColor(img_i, cv2.COLOR_RGB2LAB)

def lab2img(lab_i):
	return cv2.cvtColor(lab_i, cv2.COLOR_LAB2RGB)

def f2i(img_f):
	return (img_f*255).astype(np.uint8)

def i2f(img_i):
	return img_i.astype(np.float32)/255.0

def img2inputLum(img_i, res=None):
	lab_i = img2lab(img_i)
	if (res is not None):
		lab_i = cv2.resize(lab_i, res)
	lum_f = i2f(lab_i[:, :, 0])
	inputLum_f = lum_f[None, ..., None]
	return inputLum_f

def outputLum2img(outputL_f, img_i, res=None):
	lum_f = np.squeeze(outputL_f)
	lum_i = f2i(lum_f)
	lab_i = img2lab(img_i)
	if (res is not None):
		lum_i = cv2.resize(lum_i, res)
		lab_i = cv2.resize(lab_i, res)
	lab_i[:, :, 0] = lum_i
	oimg_i = lab2img(lab_i)
	return oimg_i


def suff(x, ext=True):
	ret = x.split('-')[-1]
	if (ext is False):
		ret = ret.split('.')[0]
	return ret

def zhigh(zenv):
	return zenv[..., 16:]

def zlow(zenv):
	return zenv[..., :16]

def gauss2d(xy, amp, x0, y0):
	x, y = xy
	a = 2.75
	inner = a * (x - x0)**2
	inner += a * (y - y0)**2
	return amp * np.exp(-inner)

def high_zenv_to_image(high_zenv):
	high_zenv = high_zenv.reshape(1,5) #.reshape(3,6)
	img = []
	for irgb, rgb in enumerate('rgb'):
		shape = (256, 512)
		X, Y = np.mgrid[0:shape[0]:1, 0:shape[1]:1]
		xy = np.array([X.flatten(), Y.flatten()])
		params_c = [high_zenv[0][irgb], *high_zenv[0][3:]] #high_zenv[irgb]
		img_c = gauss2d(xy, *params_c).reshape(shape)
		img += [img_c]
	img = np.moveaxis(img, 0, -1)
	return img

model = load_model('models/face2env.h5', custom_objects={'InstanceNormalization':InstanceNormalization, 'tf':tf}, compile=False)
envnet_decoder = load_model('models/dec.h5', compile=False)

for fname in args.face_imgs:
	face_img = read_ldr(fname)
	face_lum = img2inputLum(face_img, res=(256, 256))
	pred_src_zenv = model.predict(face_lum)
	bname = op.basename(fname)

	#*-envmap-high-2dgauss-gpred.yaml/.exr
	pred_src_zenv_high = zhigh(pred_src_zenv)
	_yml = bname.replace(suff(bname), 'envmap-high-2dgauss-gpred.yaml')
	yaml_write(_yml, pred_src_zenv_high.squeeze().tolist())
	pred_src_env_high = high_zenv_to_image(pred_src_zenv_high)
	pyexr.write(_yml.replace('.yaml', '.exr'), pred_src_env_high)
	
	#*-envmap-low-gpred.yaml/.exr
	pred_src_zenv_low = zlow(pred_src_zenv)
	_yml = bname.replace(suff(bname), 'envmap-low-gpred.yaml')
	yaml_write(_yml, pred_src_zenv_low.squeeze().tolist())
	pred_src_env_low = envnet_decoder.predict(pred_src_zenv_low.reshape(1,-1))[0]
	pyexr.write(_yml.replace('.yaml', '.exr'), pred_src_env_low)

	#*-envmap-sum-gpred.yaml/.exr
	_yml = bname.replace(suff(bname), 'envmap-gpred.yaml')
	yaml_write(_yml, pred_src_zenv.squeeze().tolist())
	pred_src_env = pred_src_env_low + pred_src_env_high
	pyexr.write(_yml.replace('.yaml', '.exr'), pred_src_env)

